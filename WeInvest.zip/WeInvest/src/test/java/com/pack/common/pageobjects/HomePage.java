package com.pack.common.pageobjects;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

public class HomePage {
	
private static WebElement element = null;

	public static WebElement ClickInvestmentIdeas(WebDriver driver){

	element = driver.findElement(By.xpath("//a[@id='btn-explore79']"));

	return element;

	}
	
}
