package com.pack.common.tests;

import java.util.concurrent.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.*;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.pack.common.pageobjects.HomePage;
import com.pack.common.pageobjects.SuggestionsPage;
import com.pack.common.pageobjects.WeatherPortfolioPage;

public class TestWeatherPortfolio {
	WebDriver driver;
	public TestWeatherPortfolio(WebDriver driver)
	{
		this.driver=driver;
	}
	
	

	public void testWeatherPortfolioPage()
	{

		String expectedText = "50%";	
		HomePage.ClickInvestmentIdeas(driver).click();
		WeatherPortfolioPage.clickCustomizePortfolio(driver).click();
		WeatherPortfolioPage.clickCustomizeButton(driver).click();
		WeatherPortfolioPage.clickAndChangeSlider(driver).click();
		WeatherPortfolioPage.clickRebalancebtn(driver).click();
		WeatherPortfolioPage.clickInvestNowbtn(driver).click();
		String actualText = SuggestionsPage.verifyPortfolio(driver).getText();
		
		Assert.assertEquals(actualText, expectedText,"Expected portfolio content is not 50%");
		
	}

}
