package com.pack.common.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SuggestionsPage {
	
	private static WebElement element = null;
	
	public static WebElement verifyPortfolio(WebDriver driver){
		
		element = driver.findElement(By.xpath(".//li[contains(@class,'list-group-item col-md-6')]//following::div[6]/span"));
		
		return element;
	}
	

}
