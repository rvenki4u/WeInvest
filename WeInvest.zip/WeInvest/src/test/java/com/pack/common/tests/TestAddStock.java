package com.pack.common.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.pack.common.pageobjects.HomePage;
import com.pack.common.pageobjects.WeatherPortfolioPage;

public class TestAddStock {

	private WebDriver driver;
	
	public TestAddStock(WebDriver driver) {
		this.driver=driver;
	}
	
	public void testAddStock(){
		
		String actualResetBtnText = "Reset";
		String actualStockText = "BT Group plc";
		
		//driver.get("https://sfo-demo.herokuapp.com/model-portfolio");
		HomePage.ClickInvestmentIdeas(driver).click();
		WeatherPortfolioPage.clickCustomizePortfolio(driver).click();
		WeatherPortfolioPage.clickCustomizeButton(driver).click();
		String resetBtnText = WeatherPortfolioPage.checkResetBtn(driver).getText();
		
		Assert.assertEquals(actualResetBtnText, resetBtnText,"Reset button is not displayed!Actual text is"+actualResetBtnText);
		
		WeatherPortfolioPage.clickAddStock(driver).click();
		WeatherPortfolioPage.switchintoAddStockWindow(driver).click();
		WeatherPortfolioPage.clickDone(driver).click();
		String expectedStockText = WeatherPortfolioPage.verifyAddedStock(driver).getText();
		Assert.assertEquals(actualStockText, expectedStockText,"Expected stock text is not present.Actual text is"+actualStockText);
		
		
			}
}
