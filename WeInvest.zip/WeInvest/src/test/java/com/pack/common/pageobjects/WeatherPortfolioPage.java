package com.pack.common.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
	
public class WeatherPortfolioPage {

	private static WebElement element = null;
	
	
	public static WebElement clickCustomizePortfolio(WebDriver driver){
		
		element = driver.findElement(By.xpath("//a[contains(text(),'Customize Portfolio')]"));
		
		return element;
	}
	
	public static WebElement clickCustomizeButton(WebDriver driver){
		
		element = driver.findElement(By.xpath("//a[contains(text(),'Customise')]"));
		
		return element;
		
	}
	
	public static WebElement clickAndChangeSlider(WebDriver driver){
		
		element = driver.findElement(By.xpath(".//div[contains(@class,'col-md-1 text-center')]//following::input"));
		
		Actions builder = new Actions(driver);
		builder.moveToElement(element, 45, 0).click().build().perform();
		
		return element;
		
	}
	
	public static WebElement clickRebalancebtn(WebDriver driver){
		
		element = driver.findElement(By.xpath(".//a[contains(text(),'Rebalance')]"));
		
		return element;
	}
	
	public static WebElement clickInvestNowbtn(WebDriver driver){
		
		element = driver.findElement(By.xpath(".//a[contains(text(),'Invest Now')]"));
		
		return element;
	}
	
	public static WebElement checkResetBtn(WebDriver driver){
		
		element = driver.findElement(By.xpath("//a[contains(text(),'Reset')]"));
		
		return element;
	}
	
	public static WebElement clickAddStock(WebDriver driver){
		
		element = driver.findElement(By.xpath("//a[contains(text(),'+ Add Stock')]"));
		return element;
	}
	
	public static WebElement switchintoAddStockWindow(WebDriver driver){
		
		WebElement element = driver.findElement(By.xpath(".//a[contains(text(),'BT Group plc')]/following::button"));
		
		String handle = driver.getWindowHandle();
		
		driver.switchTo().window(handle);
		
		/*Actions ac = new Actions(driver);
		
		ac.moveToElement(element).click().perform();*/
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		
		jse.executeScript("arguments[0].click();",element );
		
			
		return element;
	}
	
	public static WebElement clickDone(WebDriver driver){
		
		WebElement element = driver.findElement(By.xpath(".//button[contains(text(),'Done')]"));
		
		return element;
	}
	public static WebElement verifyAddedStock(WebDriver driver){
		
		WebElement element = driver.findElement(By.xpath(".//a[contains(text(),'BT Group plc')]"));
	
		return element;
		
	}
	
}
