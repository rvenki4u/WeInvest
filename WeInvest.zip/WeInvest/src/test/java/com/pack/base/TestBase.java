package com.pack.base;

import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.*;

import com.pack.common.tests.TestAddStock;
import com.pack.common.tests.TestWeatherPortfolio;

public class TestBase {
	
	
	public static WebDriver driver = null;
	Properties properties=new Properties();
	public void loadPropertyFile()
	{
	FileInputStream fis;
	try {
		String filePath=(System.getProperty("user.dir")+"\\src\\test\\java\\resources\\config.properties");
		fis = new FileInputStream(filePath);
		properties.load(fis);
	} 
	catch (FileNotFoundException e) {
	System.out.println("Property file not found");
		
	} catch (IOException e) {
		System.out.println("IO Exception while loading property file");
	
	}
	}
	
	
	@BeforeSuite
	public void initialize() throws IOException{
		loadPropertyFile();
		String driverpath =properties.getProperty("driverPath");
		System.setProperty("webdriver.chrome.driver", driverpath);
		driver 	= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
	}
	
	@BeforeMethod()
	public void launchURL()
	{
		driver.get(properties.getProperty("homeURL"));
		System.out.println("Browser launched successfully!");
	}
	@Test(priority=0,enabled=true)
	public void TestA()
	{
		new TestWeatherPortfolio(driver).testWeatherPortfolioPage();
		System.out.println("Test A passed");
	}
	
	@Test(priority=1,enabled=true)
	public void TestB()
	{
		new TestAddStock(driver).testAddStock();
		System.out.println("Test B passed");
	}
	
	
	@AfterSuite
	public void TeardownTest(){
		
		driver.quit();
	}
	
	
	
}
